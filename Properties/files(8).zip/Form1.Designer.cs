namespace ArrayTasks
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabPage1   = new System.Windows.Forms.TabPage();
            this.tabPage2   = new System.Windows.Forms.TabPage();
            this.tabPage3   = new System.Windows.Forms.TabPage();
            this.tabPage4   = new System.Windows.Forms.TabPage();
            this.tabPage5   = new System.Windows.Forms.TabPage();

            this.tabControl.SuspendLayout();
            this.SuspendLayout();

            // ── tabControl ─────────────────────────────────────────
            this.tabControl.Controls.Add(this.tabPage1);
            this.tabControl.Controls.Add(this.tabPage2);
            this.tabControl.Controls.Add(this.tabPage3);
            this.tabControl.Controls.Add(this.tabPage4);
            this.tabControl.Controls.Add(this.tabPage5);
            this.tabControl.Dock         = System.Windows.Forms.DockStyle.Fill;
            this.tabControl.Font         = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.tabControl.ItemSize     = new System.Drawing.Size(140, 30);
            this.tabControl.SizeMode     = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl.Name         = "tabControl";
            this.tabControl.SelectedIndex = 0;

            // ── tabPage1 ──────────────────────────────────────────
            this.tabPage1.Name    = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(8);
            this.tabPage1.Text    = "  Задание 1";

            // ── tabPage2 ──────────────────────────────────────────
            this.tabPage2.Name    = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(8);
            this.tabPage2.Text    = "  Задание 2";

            // ── tabPage3 ──────────────────────────────────────────
            this.tabPage3.Name    = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(8);
            this.tabPage3.Text    = "  Задание 3";

            // ── tabPage4 ──────────────────────────────────────────
            this.tabPage4.Name    = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(8);
            this.tabPage4.Text    = "  Задание 4";

            // ── tabPage5 ──────────────────────────────────────────
            this.tabPage5.Name    = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(8);
            this.tabPage5.Text    = "  Задание 5";

            // ── Form1 ─────────────────────────────────────────────
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode       = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize          = new System.Drawing.Size(960, 680);
            this.MinimumSize         = new System.Drawing.Size(980, 720);
            this.Controls.Add(this.tabControl);
            this.Font            = new System.Drawing.Font("Segoe UI", 9.5F);
            this.Name            = "Form1";
            this.Text            = "Задания с массивами и матрицами — C# WinForms";
            this.StartPosition   = System.Windows.Forms.FormStartPosition.CenterScreen;

            this.tabControl.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        // ── Designer Fields ───────────────────────────────────────
        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage    tabPage1;
        private System.Windows.Forms.TabPage    tabPage2;
        private System.Windows.Forms.TabPage    tabPage3;
        private System.Windows.Forms.TabPage    tabPage4;
        private System.Windows.Forms.TabPage    tabPage5;
    }
}
