using System;
using System.Drawing;
using System.Windows.Forms;

namespace OOP_Izdelie
{
    public partial class Form1 : Form
    {
        // ── Контролы вкладки 1 (базовый класс) ───────────────────────
        TextBox tbImya, tbKat, tbKol, tbCena, tbPost;
        TextBox tbOutDefault, tbOutArgs;

        // ── Контролы вкладки 2 (дочерние классы) ─────────────────────
        // Электроника
        TextBox tbEImya, tbEKat, tbEKol, tbECena, tbEPost, tbEBrend, tbEGar;
        TextBox tbEOut;
        // Стройматериал
        TextBox tbSImya, tbSKat, tbSKol, tbSCena, tbSPost, tbSVes, tbSMat;
        TextBox tbSOut;

        // ── Контролы вкладки 3 (виртуальный метод) ───────────────────
        TextBox tbVirtOut;

        public Form1()
        {
            InitializeComponent();
            foreach (TabPage tp in tabControl.TabPages)
                tp.BackColor = Color.FromArgb(245, 247, 252);

            BuildTab1();
            BuildTab2();
            BuildTab3();
        }

        // ═══════════════════════════════════════════════════════════
        //  ВКЛАДКА 1 — Базовый класс
        // ═══════════════════════════════════════════════════════════
        void BuildTab1()
        {
            var p = tabBase;

            Lbl(p, "Демонстрация базового класса Изделие", 10, 10,
                bold: true, size: 12, color: Color.FromArgb(30, 30, 80));

            // ── Группа: конструктор по умолчанию ──────────────────
            var grpDef = Group(p, "Конструктор по умолчанию  —  Izdelie()", 10, 40, 355, 160);
            Btn(grpDef, "Создать объект", 10, 28, 190, clicked: () =>
            {
                var obj = new Izdelie();
                tbOutDefault.Text = obj.Vivesti();
            });
            Lbl(grpDef, "Результат вызова Vivesti():", 10, 68);
            tbOutDefault = TB(grpDef, 10, 90, 325, 58, multi: true, ro: true);

            // ── Группа: конструктор с аргументами ─────────────────
            var grpArgs = Group(p, "Конструктор с аргументами  —  Izdelie(...)", 10, 215, 720, 280);

            int lx = 14, tx = 175, tw = 250;
            Lbl(grpArgs, "Имя изделия:",    lx, 32); tbImya  = TB(grpArgs, tx, 29,  tw, hint: "напр. Ноутбук");
            Lbl(grpArgs, "Категория:",      lx, 62); tbKat   = TB(grpArgs, tx, 59,  tw, hint: "напр. Электроника");
            Lbl(grpArgs, "Количество (шт):",lx, 92); tbKol   = NumTB(grpArgs, tx, 89, tw);
            Lbl(grpArgs, "Цена (руб):",     lx,122); tbCena  = DecTB(grpArgs, tx, 119, tw);
            Lbl(grpArgs, "Поставщик:",      lx,152); tbPost  = TB(grpArgs, tx, 149, tw, hint: "напр. ООО Ромашка");

            Btn(grpArgs, "Создать объект и вызвать Vivesti()", 14, 185, 320, clicked: () =>
            {
                try
                {
                    var obj = new Izdelie(
                        tbImya.Text.Trim(),
                        tbKat.Text.Trim(),
                        int.Parse(tbKol.Text),
                        double.Parse(tbCena.Text.Replace('.', ',')),
                        tbPost.Text.Trim()
                    );
                    tbOutArgs.Text = obj.Vivesti();
                }
                catch (Exception ex) { Err(ex.Message); }
            });

            Lbl(grpArgs, "Результат:", 14, 218);
            tbOutArgs = TB(grpArgs, 14, 238, 686, 30, multi: true, ro: true);
        }

        // ═══════════════════════════════════════════════════════════
        //  ВКЛАДКА 2 — Дочерние классы
        // ═══════════════════════════════════════════════════════════
        void BuildTab2()
        {
            var p = tabChild;

            Lbl(p, "Дочерние классы: Elektronika и Strojmaterial", 10, 10,
                bold: true, size: 12, color: Color.FromArgb(30, 30, 80));

            // ── Elektronika ──────────────────────────────────────
            var grpE = Group(p, "Elektronika  :  Izdelie", 10, 40, 345, 460);

            int lx = 10, tx = 170, tw = 155;
            Lbl(grpE, "Имя:",          lx, 30);  tbEImya  = TB(grpE, tx, 27,  tw, hint: "Смартфон");
            Lbl(grpE, "Категория:",    lx, 58);  tbEKat   = TB(grpE, tx, 55,  tw, hint: "Гаджеты");
            Lbl(grpE, "Количество:",   lx, 86);  tbEKol   = NumTB(grpE, tx, 83, tw);
            Lbl(grpE, "Цена (руб):",   lx,114);  tbECena  = DecTB(grpE, tx, 111,tw);
            Lbl(grpE, "Поставщик:",    lx,142);  tbEPost  = TB(grpE, tx, 139, tw, hint: "TechImport");
            Lbl(grpE, "Бренд:",        lx,170);  tbEBrend = TB(grpE, tx, 167, tw, hint: "Samsung");
            Lbl(grpE, "Гарантия (лет):",lx,198); tbEGar   = DecTB(grpE, tx, 195,tw);

            Btn(grpE, "Создать Elektronika", 10, 232, 200, clicked: () =>
            {
                try
                {
                    var obj = new Elektronika(
                        tbEImya.Text.Trim(), tbEKat.Text.Trim(),
                        int.Parse(tbEKol.Text),
                        double.Parse(tbECena.Text.Replace('.', ',')),
                        tbEPost.Text.Trim(),
                        tbEBrend.Text.Trim(),
                        double.Parse(tbEGar.Text.Replace('.', ','))
                    );
                    tbEOut.Text = obj.Vivesti() +
                        $"\nБренд: {obj.Brend}\nГарантия: {obj.Garantiya} лет";
                }
                catch (Exception ex) { Err(ex.Message); }
            });

            Lbl(grpE, "Результат:", 10, 270);
            tbEOut = TB(grpE, 10, 292, 318, 148, multi: true, ro: true);

            // ── Strojmaterial ─────────────────────────────────────
            var grpS = Group(p, "Strojmaterial  :  Izdelie", 375, 40, 345, 460);

            Lbl(grpS, "Имя:",         lx, 30);  tbSImya = TB(grpS, tx, 27,  tw, hint: "Кирпич");
            Lbl(grpS, "Категория:",   lx, 58);  tbSKat  = TB(grpS, tx, 55,  tw, hint: "Кладочные");
            Lbl(grpS, "Количество:",  lx, 86);  tbSKol  = NumTB(grpS, tx, 83, tw);
            Lbl(grpS, "Цена (руб):",  lx,114);  tbSCena = DecTB(grpS, tx, 111,tw);
            Lbl(grpS, "Поставщик:",   lx,142);  tbSPost = TB(grpS, tx, 139, tw, hint: "СтройБаза");
            Lbl(grpS, "Вес (кг):",    lx,170);  tbSVes  = DecTB(grpS, tx, 167,tw);
            Lbl(grpS, "Материал:",    lx,198);  tbSMat  = TB(grpS, tx, 195, tw, hint: "Керамика");

            Btn(grpS, "Создать Strojmaterial", 10, 232, 200, clicked: () =>
            {
                try
                {
                    var obj = new Strojmaterial(
                        tbSImya.Text.Trim(), tbSKat.Text.Trim(),
                        int.Parse(tbSKol.Text),
                        double.Parse(tbSCena.Text.Replace('.', ',')),
                        tbSPost.Text.Trim(),
                        double.Parse(tbSVes.Text.Replace('.', ',')),
                        tbSMat.Text.Trim()
                    );
                    tbSOut.Text = obj.Vivesti() +
                        $"\nМатериал: {obj.Material}\nВес: {obj.Ves} кг";
                }
                catch (Exception ex) { Err(ex.Message); }
            });

            Lbl(grpS, "Результат:", 10, 270);
            tbSOut = TB(grpS, 10, 292, 318, 148, multi: true, ro: true);
        }

        // ═══════════════════════════════════════════════════════════
        //  ВКЛАДКА 3 — Виртуальный метод
        // ═══════════════════════════════════════════════════════════
        void BuildTab3()
        {
            var p = tabVirt;

            Lbl(p, "Демонстрация виртуального метода GetInfo()", 10, 10,
                bold: true, size: 12, color: Color.FromArgb(30, 30, 80));

            Lbl(p, "Один и тот же метод GetInfo() — разный результат в зависимости от типа объекта:", 10, 40,
                color: Color.FromArgb(80, 80, 80));

            Btn(p, "Вызвать GetInfo() для всех трёх объектов", 10, 72, 380, clicked: () =>
            {
                // Три объекта через общую ссылку типа Izdelie
                Izdelie obj1 = new Izdelie("Болт М8",  "Крепёж", 500,  2.5,  "МеталлОпт");
                Izdelie obj2 = new Elektronika("Роутер", "Сети", 20, 3500, "NetPro", "TP-Link", 2);
                Izdelie obj3 = new Strojmaterial("Доска 50x100", "Пиломатериалы", 200, 85, "ЛесТорг", 3.2, "Сосна");

                tbVirtOut.Text =
                    "Объект 1 — Izdelie:\r\n"       + obj1.GetInfo() + "\r\n\r\n" +
                    "Объект 2 — Elektronika:\r\n"   + obj2.GetInfo() + "\r\n\r\n" +
                    "Объект 3 — Strojmaterial:\r\n" + obj3.GetInfo() + "\r\n\r\n" +
                    "─────────────────────────────────────────────────\r\n" +
                    "Все три переменные объявлены как  Izdelie,\r\n" +
                    "но каждый объект вызывает СВОЮ версию метода.\r\n" +
                    "Это и есть полиморфизм.";
            });

            Lbl(p, "Вывод:", 10, 118);
            tbVirtOut = TB(p, 10, 140, 720, 360, multi: true, ro: true);
            tbVirtOut.Font = new System.Drawing.Font("Consolas", 10f);
        }

        // ═══════════════════════════════════════════════════════════
        //  ФАБРИКА КОНТРОЛОВ
        // ═══════════════════════════════════════════════════════════

        Label Lbl(Control p, string text, int x, int y,
            bool bold = false, float size = 9.5f, Color? color = null)
        {
            var l = new Label
            {
                Text      = text,
                Location  = new Point(x, y),
                AutoSize  = true,
                Font      = new System.Drawing.Font("Segoe UI", size,
                                bold ? System.Drawing.FontStyle.Bold : System.Drawing.FontStyle.Regular),
                ForeColor = color ?? Color.FromArgb(20, 20, 20),
                BackColor = Color.Transparent,
            };
            p.Controls.Add(l);
            return l;
        }

        TextBox TB(Control p, int x, int y, int w, int h = 24,
            bool multi = false, bool ro = false, string hint = "")
        {
            var tb = new TextBox
            {
                Location   = new Point(x, y),
                Width      = w,
                Height     = h,
                Multiline  = multi,
                ReadOnly   = ro,
                ScrollBars = multi ? ScrollBars.Vertical : ScrollBars.None,
                Font       = new System.Drawing.Font("Segoe UI", 9.5f),
                BackColor  = ro ? Color.FromArgb(240, 242, 248) : Color.White,
            };
            if (hint != "" && !ro)
            {
                // Подсказка через PlaceholderText (доступно в .NET 5+)
                // Для совместимости используем GotFocus/LostFocus
                tb.ForeColor = Color.Gray;
                tb.Text      = hint;
                tb.GotFocus  += (s, e) => { if (tb.Text == hint) { tb.Text = ""; tb.ForeColor = Color.Black; } };
                tb.LostFocus += (s, e) => { if (tb.Text == "") { tb.Text = hint; tb.ForeColor = Color.Gray; } };
            }
            p.Controls.Add(tb);
            return tb;
        }

        // TextBox только для целых чисел
        TextBox NumTB(Control p, int x, int y, int w)
        {
            var tb = TB(p, x, y, w);
            tb.Text = "0";
            tb.KeyPress += (s, e) =>
            {
                if (!char.IsDigit(e.KeyChar) && e.KeyChar != '\b') e.Handled = true;
            };
            return tb;
        }

        // TextBox для дробных чисел
        TextBox DecTB(Control p, int x, int y, int w)
        {
            var tb = TB(p, x, y, w);
            tb.Text = "0";
            tb.KeyPress += (s, e) =>
            {
                if (!char.IsDigit(e.KeyChar) && e.KeyChar != '\b'
                    && e.KeyChar != '.' && e.KeyChar != ',') e.Handled = true;
            };
            return tb;
        }

        Button Btn(Control p, string text, int x, int y, int w, Action clicked)
        {
            var b = new Button
            {
                Text      = text,
                Location  = new Point(x, y),
                Size      = new Size(w, 30),
                BackColor = Color.FromArgb(67, 97, 238),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font      = new System.Drawing.Font("Segoe UI", 9.5f,
                                System.Drawing.FontStyle.Bold),
                Cursor    = Cursors.Hand,
            };
            b.FlatAppearance.BorderSize = 0;
            b.Click += (s, e) => clicked();
            p.Controls.Add(b);
            return b;
        }

        GroupBox Group(Control p, string text, int x, int y, int w, int h)
        {
            var g = new GroupBox
            {
                Text      = text,
                Location  = new Point(x, y),
                Size      = new Size(w, h),
                Font      = new System.Drawing.Font("Segoe UI", 9.5f,
                                System.Drawing.FontStyle.Bold),
                ForeColor = Color.FromArgb(50, 50, 120),
                BackColor = Color.Transparent,
            };
            p.Controls.Add(g);
            return g;
        }

        void Err(string msg) =>
            MessageBox.Show(msg, "Ошибка ввода",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
    }
}
