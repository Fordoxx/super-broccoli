namespace OOP_Izdelie
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.tabControl = new System.Windows.Forms.TabControl();
            this.tabBase    = new System.Windows.Forms.TabPage();
            this.tabChild   = new System.Windows.Forms.TabPage();
            this.tabVirt    = new System.Windows.Forms.TabPage();

            this.tabControl.SuspendLayout();
            this.SuspendLayout();

            this.tabControl.Dock          = System.Windows.Forms.DockStyle.Fill;
            this.tabControl.Font          = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.tabControl.ItemSize      = new System.Drawing.Size(200, 30);
            this.tabControl.SizeMode      = System.Windows.Forms.TabSizeMode.Fixed;
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Controls.Add(this.tabBase);
            this.tabControl.Controls.Add(this.tabChild);
            this.tabControl.Controls.Add(this.tabVirt);

            this.tabBase.Name    = "tabBase";
            this.tabBase.Text    = "  Базовый класс";
            this.tabBase.Padding = new System.Windows.Forms.Padding(10);

            this.tabChild.Name    = "tabChild";
            this.tabChild.Text    = "  Дочерние классы";
            this.tabChild.Padding = new System.Windows.Forms.Padding(10);

            this.tabVirt.Name    = "tabVirt";
            this.tabVirt.Text    = "  Виртуальный метод";
            this.tabVirt.Padding = new System.Windows.Forms.Padding(10);

            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode       = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize          = new System.Drawing.Size(760, 580);
            this.FormBorderStyle     = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox         = false;
            this.StartPosition       = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text                = "ООП — Класс Изделие";
            this.Font                = new System.Drawing.Font("Segoe UI", 9.5F);
            this.Controls.Add(this.tabControl);

            this.tabControl.ResumeLayout(false);
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.TabControl tabControl;
        private System.Windows.Forms.TabPage    tabBase;
        private System.Windows.Forms.TabPage    tabChild;
        private System.Windows.Forms.TabPage    tabVirt;
    }
}
