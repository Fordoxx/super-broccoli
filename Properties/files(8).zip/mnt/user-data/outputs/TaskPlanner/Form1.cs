using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Windows.Forms;

namespace TaskPlanner
{
    public partial class Form1 : Form
    {
        // ── Хранилище задач ───────────────────────────────────────────
        private List<TaskItem> allTasks = new List<TaskItem>();
        private List<TaskItem> shownTasks = new List<TaskItem>();

        public Form1()
        {
            InitializeComponent();
            SetupGrid();
            RefreshGrid();
        }

        // ── Настройка столбцов DataGridView ───────────────────────────
        void SetupGrid()
        {
            dgvTasks.Columns.Clear();

            var colDate = new DataGridViewTextBoxColumn
                { Name = "Date",   HeaderText = "Дата",      FillWeight = 12 };
            var colTime = new DataGridViewTextBoxColumn
                { Name = "Time",   HeaderText = "Время",     FillWeight = 12 };
            var colTitle = new DataGridViewTextBoxColumn
                { Name = "Title",  HeaderText = "Задача",    FillWeight = 35 };
            var colDesc = new DataGridViewTextBoxColumn
                { Name = "Desc",   HeaderText = "Описание",  FillWeight = 28 };
            var colStatus = new DataGridViewTextBoxColumn
                { Name = "Status", HeaderText = "Статус",    FillWeight = 13 };

            colTitle.DefaultCellStyle.Font = new Font("Segoe UI", 10f, FontStyle.Bold);
            colStatus.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

            dgvTasks.Columns.AddRange(colDate, colTime, colTitle, colDesc, colStatus);

            // Двойная буферизация
            typeof(DataGridView)
                .GetProperty("DoubleBuffered",
                    System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.NonPublic)
                ?.SetValue(dgvTasks, true, null);
        }

        // ── Обновить таблицу ──────────────────────────────────────────
        void RefreshGrid()
        {
            DateTime filterDate = dtpFilter.Value.Date;
            bool onlyActive = chkOnlyActive.Checked;

            shownTasks = allTasks
                .Where(t => t.Date == filterDate)
                .Where(t => !onlyActive || !t.IsDone)
                .OrderBy(t => t.AllDay ? TimeSpan.MaxValue : t.Time)
                .ToList();

            dgvTasks.Rows.Clear();

            foreach (var t in shownTasks)
            {
                int idx = dgvTasks.Rows.Add(
                    t.Date.ToString("dd.MM.yyyy"),
                    t.TimeLabel,
                    t.Title,
                    t.Description,
                    t.StatusLabel
                );

                // Цвет строки по статусу
                var row = dgvTasks.Rows[idx];
                if (t.IsDone)
                {
                    row.DefaultCellStyle.ForeColor = Color.Gray;
                    row.DefaultCellStyle.BackColor = Color.FromArgb(230, 240, 230);
                }
                else
                {
                    row.DefaultCellStyle.BackColor = Color.White;
                }
            }

            int total = allTasks.Count(t => t.Date == filterDate);
            int done  = allTasks.Count(t => t.Date == filterDate && t.IsDone);
            lblStatus.Text = $"Показано: {shownTasks.Count}  |  Всего: {total}  |  Выполнено: {done}";
        }

        // ── Получить выбранную задачу ─────────────────────────────────
        TaskItem GetSelected()
        {
            if (dgvTasks.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите задачу в таблице.", "Внимание",
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return null;
            }
            int idx = dgvTasks.SelectedRows[0].Index;
            return shownTasks[idx];
        }

        // ═══════════════════════════════════════════════════════════
        //  ОБРАБОТЧИКИ
        // ═══════════════════════════════════════════════════════════

        // Добавить задачу
        void BtnAdd_Click(object sender, EventArgs e)
        {
            using (var dlg = new AddTaskForm())
            {
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    allTasks.Add(dlg.Result);
                    dtpFilter.Value = dlg.Result.Date;
                    RefreshGrid();
                }
            }
        }

        // Редактировать
        void BtnEdit_Click(object sender, EventArgs e)
        {
            var task = GetSelected();
            if (task == null) return;

            using (var dlg = new AddTaskForm(task))
            {
                if (dlg.ShowDialog() == DialogResult.OK)
                {
                    // Сохраняем Id и статус, обновляем остальное
                    dlg.Result.Id     = task.Id;
                    dlg.Result.IsDone = task.IsDone;
                    int idx = allTasks.IndexOf(task);
                    allTasks[idx] = dlg.Result;
                    RefreshGrid();
                }
            }
        }

        // Удалить
        void BtnDelete_Click(object sender, EventArgs e)
        {
            var task = GetSelected();
            if (task == null) return;

            var confirm = MessageBox.Show(
                $"Удалить задачу «{task.Title}»?",
                "Подтверждение",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question);

            if (confirm == DialogResult.Yes)
            {
                allTasks.Remove(task);
                RefreshGrid();
            }
        }

        // Отметить выполненной / снять отметку
        void BtnDone_Click(object sender, EventArgs e)
        {
            var task = GetSelected();
            if (task == null) return;

            task.IsDone = !task.IsDone;
            RefreshGrid();
        }

        // Двойной клик — редактировать
        void DgvTasks_CellDoubleClick(object sender,
            DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) BtnEdit_Click(sender, e);
        }

        // Фильтр по дате / галочка
        void BtnFilter_Click(object sender, EventArgs e) => RefreshGrid();

        // Меню — задачи на сегодня
        void MiViewDay_Click(object sender, EventArgs e)
        {
            dtpFilter.Value = DateTime.Today;
            chkOnlyActive.Checked = false;
            RefreshGrid();
        }

        // ── Сохранить в файл ──────────────────────────────────────────
        void MiSave_Click(object sender, EventArgs e)
        {
            using (var sfd = new SaveFileDialog())
            {
                sfd.Filter   = "Текстовые файлы (*.txt)|*.txt";
                sfd.FileName = "tasks.txt";
                if (sfd.ShowDialog() == DialogResult.OK)
                {
                    var lines = allTasks.Select(t => t.ToFileLine());
                    File.WriteAllLines(sfd.FileName, lines);
                    MessageBox.Show($"Сохранено {allTasks.Count} задач.", "Готово",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        // ── Загрузить из файла ────────────────────────────────────────
        void MiLoad_Click(object sender, EventArgs e)
        {
            using (var ofd = new OpenFileDialog())
            {
                ofd.Filter = "Текстовые файлы (*.txt)|*.txt";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    var loaded = new List<TaskItem>();
                    foreach (var line in File.ReadAllLines(ofd.FileName))
                    {
                        var t = TaskItem.FromFileLine(line);
                        if (t != null) loaded.Add(t);
                    }
                    allTasks = loaded;
                    RefreshGrid();
                    MessageBox.Show($"Загружено {allTasks.Count} задач.", "Готово",
                        MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }
    }
}
