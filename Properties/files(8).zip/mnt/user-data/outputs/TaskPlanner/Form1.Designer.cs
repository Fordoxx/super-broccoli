namespace TaskPlanner
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.menuStrip      = new System.Windows.Forms.MenuStrip();
            this.miTasks        = new System.Windows.Forms.ToolStripMenuItem();
            this.miAdd          = new System.Windows.Forms.ToolStripMenuItem();
            this.miViewDay      = new System.Windows.Forms.ToolStripMenuItem();
            this.miSave         = new System.Windows.Forms.ToolStripMenuItem();
            this.miLoad         = new System.Windows.Forms.ToolStripMenuItem();
            this.dtpFilter      = new System.Windows.Forms.DateTimePicker();
            this.btnFilter      = new System.Windows.Forms.Button();
            this.chkOnlyActive  = new System.Windows.Forms.CheckBox();
            this.dgvTasks       = new System.Windows.Forms.DataGridView();
            this.btnAdd         = new System.Windows.Forms.Button();
            this.btnEdit        = new System.Windows.Forms.Button();
            this.btnDelete      = new System.Windows.Forms.Button();
            this.btnDone        = new System.Windows.Forms.Button();
            this.lblStatus      = new System.Windows.Forms.Label();

            this.menuStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)this.dgvTasks).BeginInit();
            this.SuspendLayout();

            // ── menuStrip ─────────────────────────────────────────
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[]
                { this.miTasks });
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name     = "menuStrip";
            this.menuStrip.Size     = new System.Drawing.Size(860, 24);
            this.menuStrip.Font     = new System.Drawing.Font("Segoe UI", 10F);

            this.miTasks.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[]
                { this.miAdd, this.miViewDay, 
                  new System.Windows.Forms.ToolStripSeparator(),
                  this.miSave, this.miLoad });
            this.miTasks.Name = "miTasks";
            this.miTasks.Text = "Задачи";

            this.miAdd.Name     = "miAdd";
            this.miAdd.Text     = "➕  Добавить задачу";
            this.miAdd.ShortcutKeys = System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N;
            this.miAdd.Click   += new System.EventHandler(this.BtnAdd_Click);

            this.miViewDay.Name  = "miViewDay";
            this.miViewDay.Text  = "📅  Задачи на сегодня";
            this.miViewDay.Click += new System.EventHandler(this.MiViewDay_Click);

            this.miSave.Name     = "miSave";
            this.miSave.Text     = "💾  Сохранить в файл";
            this.miSave.ShortcutKeys = System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S;
            this.miSave.Click   += new System.EventHandler(this.MiSave_Click);

            this.miLoad.Name     = "miLoad";
            this.miLoad.Text     = "📂  Загрузить из файла";
            this.miLoad.Click   += new System.EventHandler(this.MiLoad_Click);

            // ── dtpFilter ─────────────────────────────────────────
            this.dtpFilter.Location = new System.Drawing.Point(14, 38);
            this.dtpFilter.Width    = 150;
            this.dtpFilter.Format   = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpFilter.Value    = System.DateTime.Today;
            this.dtpFilter.Font     = new System.Drawing.Font("Segoe UI", 10F);

            // ── btnFilter ─────────────────────────────────────────
            this.btnFilter.Text      = "🔍  Показать";
            this.btnFilter.Location  = new System.Drawing.Point(174, 36);
            this.btnFilter.Size      = new System.Drawing.Size(110, 28);
            this.btnFilter.BackColor = System.Drawing.Color.FromArgb(67, 97, 238);
            this.btnFilter.ForeColor = System.Drawing.Color.White;
            this.btnFilter.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnFilter.Font      = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnFilter.Cursor    = System.Windows.Forms.Cursors.Hand;
            this.btnFilter.FlatAppearance.BorderSize = 0;
            this.btnFilter.Click    += new System.EventHandler(this.BtnFilter_Click);

            // ── chkOnlyActive ─────────────────────────────────────
            this.chkOnlyActive.Text      = "Только невыполненные";
            this.chkOnlyActive.Location  = new System.Drawing.Point(300, 40);
            this.chkOnlyActive.AutoSize  = true;
            this.chkOnlyActive.Font      = new System.Drawing.Font("Segoe UI", 10F);
            this.chkOnlyActive.CheckedChanged += new System.EventHandler(this.BtnFilter_Click);

            // ── dgvTasks ──────────────────────────────────────────
            this.dgvTasks.Location                    = new System.Drawing.Point(14, 80);
            this.dgvTasks.Size                        = new System.Drawing.Size(830, 460);
            this.dgvTasks.AllowUserToAddRows          = false;
            this.dgvTasks.AllowUserToDeleteRows       = false;
            this.dgvTasks.ReadOnly                    = true;
            this.dgvTasks.SelectionMode               = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvTasks.MultiSelect                 = false;
            this.dgvTasks.BackgroundColor             = System.Drawing.Color.FromArgb(245, 247, 252);
            this.dgvTasks.BorderStyle                 = System.Windows.Forms.BorderStyle.FixedSingle;
            this.dgvTasks.GridColor                   = System.Drawing.Color.FromArgb(200, 210, 230);
            this.dgvTasks.RowHeadersVisible           = false;
            this.dgvTasks.AutoSizeColumnsMode         = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvTasks.ColumnHeadersHeight         = 30;
            this.dgvTasks.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this.dgvTasks.EnableHeadersVisualStyles   = false;
            this.dgvTasks.Font                        = new System.Drawing.Font("Segoe UI", 10F);
            this.dgvTasks.RowTemplate.Height          = 32;
            this.dgvTasks.ColumnHeadersDefaultCellStyle.Font      = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.dgvTasks.ColumnHeadersDefaultCellStyle.BackColor = System.Drawing.Color.FromArgb(200, 215, 255);
            this.dgvTasks.ColumnHeadersDefaultCellStyle.ForeColor = System.Drawing.Color.FromArgb(30, 30, 90);
            this.dgvTasks.ColumnHeadersDefaultCellStyle.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            this.dgvTasks.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.DgvTasks_CellDoubleClick);

            // ── Кнопки управления ─────────────────────────────────
            this.btnAdd.Text      = "➕  Добавить";
            this.btnAdd.Location  = new System.Drawing.Point(14, 554);
            this.btnAdd.Size      = new System.Drawing.Size(120, 32);
            this.btnAdd.BackColor = System.Drawing.Color.FromArgb(67, 97, 238);
            this.btnAdd.ForeColor = System.Drawing.Color.White;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Font      = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnAdd.Cursor    = System.Windows.Forms.Cursors.Hand;
            this.btnAdd.FlatAppearance.BorderSize = 0;
            this.btnAdd.Click    += new System.EventHandler(this.BtnAdd_Click);

            this.btnEdit.Text      = "✏  Изменить";
            this.btnEdit.Location  = new System.Drawing.Point(144, 554);
            this.btnEdit.Size      = new System.Drawing.Size(120, 32);
            this.btnEdit.BackColor = System.Drawing.Color.FromArgb(194, 120, 10);
            this.btnEdit.ForeColor = System.Drawing.Color.White;
            this.btnEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnEdit.Font      = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnEdit.Cursor    = System.Windows.Forms.Cursors.Hand;
            this.btnEdit.FlatAppearance.BorderSize = 0;
            this.btnEdit.Click    += new System.EventHandler(this.BtnEdit_Click);

            this.btnDelete.Text      = "🗑  Удалить";
            this.btnDelete.Location  = new System.Drawing.Point(274, 554);
            this.btnDelete.Size      = new System.Drawing.Size(120, 32);
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(185, 28, 28);
            this.btnDelete.ForeColor = System.Drawing.Color.White;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Font      = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnDelete.Cursor    = System.Windows.Forms.Cursors.Hand;
            this.btnDelete.FlatAppearance.BorderSize = 0;
            this.btnDelete.Click    += new System.EventHandler(this.BtnDelete_Click);

            this.btnDone.Text      = "✔  Отметить выполненной";
            this.btnDone.Location  = new System.Drawing.Point(404, 554);
            this.btnDone.Size      = new System.Drawing.Size(210, 32);
            this.btnDone.BackColor = System.Drawing.Color.FromArgb(22, 163, 74);
            this.btnDone.ForeColor = System.Drawing.Color.White;
            this.btnDone.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDone.Font      = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnDone.Cursor    = System.Windows.Forms.Cursors.Hand;
            this.btnDone.FlatAppearance.BorderSize = 0;
            this.btnDone.Click    += new System.EventHandler(this.BtnDone_Click);

            // ── lblStatus ─────────────────────────────────────────
            this.lblStatus.Text      = "";
            this.lblStatus.Location  = new System.Drawing.Point(630, 562);
            this.lblStatus.Size      = new System.Drawing.Size(214, 20);
            this.lblStatus.Font      = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Italic);
            this.lblStatus.ForeColor = System.Drawing.Color.FromArgb(100, 100, 120);
            this.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleRight;

            // ── Form1 ─────────────────────────────────────────────
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode       = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize          = new System.Drawing.Size(858, 600);
            this.FormBorderStyle     = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox         = false;
            this.MainMenuStrip       = this.menuStrip;
            this.StartPosition       = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text                = "Планировщик задач";
            this.BackColor           = System.Drawing.Color.FromArgb(245, 247, 252);

            this.Controls.Add(this.menuStrip);
            this.Controls.Add(this.dtpFilter);
            this.Controls.Add(this.btnFilter);
            this.Controls.Add(this.chkOnlyActive);
            this.Controls.Add(this.dgvTasks);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnDone);
            this.Controls.Add(this.lblStatus);

            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)this.dgvTasks).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        System.Windows.Forms.MenuStrip       menuStrip;
        System.Windows.Forms.ToolStripMenuItem miTasks, miAdd, miViewDay, miSave, miLoad;
        System.Windows.Forms.DateTimePicker  dtpFilter;
        System.Windows.Forms.Button          btnFilter, btnAdd, btnEdit, btnDelete, btnDone;
        System.Windows.Forms.CheckBox        chkOnlyActive;
        System.Windows.Forms.DataGridView    dgvTasks;
        System.Windows.Forms.Label           lblStatus;
    }
}
