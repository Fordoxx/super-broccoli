using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace DelegateTask
{
    // ── Делегат для методов работы с массивом ─────────────────────────
    public delegate string ArrayMethod(int[] arr);

    public class Form1 : Form
    {
        // ── Событие (скорректированное задание) ───────────────────────
        public event ArrayMethod OnCalculate;

        // ── Контролы ──────────────────────────────────────────────────
        TextBox  tbA, tbB;
        TextBox  tbArray;
        TextBox  tbResult;
        Button   btnGenerate, btnRun;
        int[]    currentArray;

        public Form1()
        {
            this.Text            = "Делегаты и события — Массив";
            this.Size            = new Size(520, 560);
            this.StartPosition   = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox     = false;
            this.Font            = new Font("Segoe UI", 10f);
            this.BackColor       = Color.FromArgb(245, 247, 252);

            BuildUI();

            // ── Подписка методов на событие ───────────────────────────
            OnCalculate += CountEven;
            OnCalculate += FindMax;
            OnCalculate += SortAsc;
        }

        void BuildUI()
        {
            // ── Заголовок ─────────────────────────────────────────────
            var lblTitle = new Label
            {
                Text      = "Работа с массивом через делегат и событие",
                Location  = new Point(14, 12),
                Size      = new Size(476, 22),
                Font      = new Font("Segoe UI", 11f, FontStyle.Bold),
                ForeColor = Color.FromArgb(30, 30, 80),
            };

            // ── Ввод A и B ────────────────────────────────────────────
            var lblA = Lbl("Введите A:", 14, 50);
            tbA = TB(110, 47, 80, "1");
            tbA.KeyPress += NumOnly;

            var lblB = Lbl("Введите B (B>A):", 210, 50);
            tbB = TB(355, 47, 80, "100");
            tbB.KeyPress += NumOnly;

            // ── Кнопка генерации ──────────────────────────────────────
            btnGenerate = Btn("🎲  Сгенерировать массив", 14, 90, 230);
            btnGenerate.Click += BtnGenerate_Click;

            // ── Вывод массива ─────────────────────────────────────────
            var lblArr = Lbl("Сгенерированный массив (10 элементов):", 14, 135);
            tbArray = new TextBox
            {
                Location  = new Point(14, 158),
                Size      = new Size(476, 28),
                ReadOnly  = true,
                BackColor = Color.FromArgb(220, 230, 255),
                Font      = new Font("Consolas", 11f, FontStyle.Bold),
            };

            // ── Кнопка запуска расчётов ───────────────────────────────
            btnRun = Btn("▶  Выполнить все расчёты (через событие)", 14, 200, 340);
            btnRun.BackColor = Color.FromArgb(22, 163, 74);
            btnRun.Click    += BtnRun_Click;
            btnRun.Enabled   = false;

            // ── Результат ─────────────────────────────────────────────
            var lblRes = Lbl("Результат:", 14, 248);
            tbResult = new TextBox
            {
                Location   = new Point(14, 272),
                Size       = new Size(476, 238),
                Multiline  = true,
                ReadOnly   = true,
                ScrollBars = ScrollBars.Vertical,
                BackColor  = Color.FromArgb(209, 250, 229),
                Font       = new Font("Consolas", 10f),
            };

            this.Controls.AddRange(new Control[]
            {
                lblTitle, lblA, tbA, lblB, tbB,
                btnGenerate, lblArr, tbArray,
                btnRun, lblRes, tbResult
            });
        }

        // ── Генерация массива ─────────────────────────────────────────
        void BtnGenerate_Click(object sender, EventArgs e)
        {
            // Проверка корректности ввода
            if (!int.TryParse(tbA.Text.Trim(), out int a))
            {
                Err("Введите корректное целое число для A."); return;
            }
            if (!int.TryParse(tbB.Text.Trim(), out int b))
            {
                Err("Введите корректное целое число для B."); return;
            }
            if (a >= b)
            {
                Err("Ошибка: A должно быть меньше B (A < B)."); return;
            }

            var rng = new Random();
            currentArray = new int[10];
            for (int i = 0; i < 10; i++)
                currentArray[i] = rng.Next(a, b + 1);

            tbArray.Text   = string.Join(",  ", currentArray);
            tbResult.Text  = "";
            btnRun.Enabled = true;
        }

        // ── Запуск расчётов через событие ────────────────────────────
        void BtnRun_Click(object sender, EventArgs e)
        {
            if (currentArray == null) return;

            tbResult.Text = "";

            // Вызов события — все подписанные методы выполняются
            // GetInvocationList позволяет получить результат каждого
            tbResult.AppendText("=== Вызов методов через событие OnCalculate ===\r\n\r\n");

            foreach (ArrayMethod method in OnCalculate.GetInvocationList())
            {
                string result = method.Invoke(currentArray);
                tbResult.AppendText(result + "\r\n\r\n");
            }
        }

        // ═══════════════════════════════════════════════════════════
        //  МЕТОДЫ — передаются через делегат / событие
        // ═══════════════════════════════════════════════════════════

        // Метод 1 — подсчёт чётных чисел
        string CountEven(int[] arr)
        {
            int count = arr.Count(x => x % 2 == 0);
            return $"[Метод 1] Количество чётных чисел: {count}";
        }

        // Метод 2 — максимальный элемент
        string FindMax(int[] arr)
        {
            int max = arr.Max();
            int idx = Array.IndexOf(arr, max);
            return $"[Метод 2] Максимальный элемент: {max}  (индекс {idx})";
        }

        // Метод 3 — сортировка по возрастанию
        string SortAsc(int[] arr)
        {
            int[] sorted = (int[])arr.Clone();
            Array.Sort(sorted);
            return $"[Метод 3] Массив по возрастанию:\r\n         {string.Join(",  ", sorted)}";
        }

        // ═══════════════════════════════════════════════════════════
        //  ВСПОМОГАТЕЛЬНЫЕ
        // ═══════════════════════════════════════════════════════════

        // Разрешаем вводить только цифры и минус
        void NumOnly(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '\b' && e.KeyChar != '-')
                e.Handled = true;
        }

        void Err(string msg) =>
            MessageBox.Show(msg, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);

        Label Lbl(string text, int x, int y)
        {
            var l = new Label { Text = text, Location = new Point(x, y),
                AutoSize = true, BackColor = Color.Transparent };
            this.Controls.Add(l);
            return l;
        }

        TextBox TB(int x, int y, int w, string def = "")
        {
            var tb = new TextBox { Location = new Point(x, y), Width = w, Text = def };
            this.Controls.Add(tb);
            return tb;
        }

        Button Btn(string text, int x, int y, int w)
        {
            var b = new Button
            {
                Text      = text,
                Location  = new Point(x, y),
                Size      = new Size(w, 32),
                BackColor = Color.FromArgb(67, 97, 238),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font      = new Font("Segoe UI", 10f, FontStyle.Bold),
                Cursor    = Cursors.Hand,
            };
            b.FlatAppearance.BorderSize = 0;
            this.Controls.Add(b);
            return b;
        }
    }
}
