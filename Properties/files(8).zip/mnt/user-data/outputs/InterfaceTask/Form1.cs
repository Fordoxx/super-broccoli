using System;
using System.Drawing;
using System.Windows.Forms;

namespace InterfaceTask
{
    public class Form1 : Form
    {
        Label      lblNout, lblElek;
        TextBox    tbNoutInfo, tbElekInfo;
        Label      lblNoutCena, lblElekCena;
        Button     btnNout, btnElek;

        public Form1()
        {
            this.Text          = "Интерфейс IIzdelie";
            this.Size          = new Size(500, 520);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox   = false;
            this.Font          = new Font("Segoe UI", 10f);

            // ── Ноутбук ──────────────────────────────────────────
            lblNout = new Label();
            lblNout.Text     = "Класс Notebook (реализует IIzdelie):";
            lblNout.Location = new Point(20, 20);
            lblNout.Size     = new Size(440, 22);
            lblNout.Font     = new Font("Segoe UI", 10f, FontStyle.Bold);

            tbNoutInfo = new TextBox();
            tbNoutInfo.Location   = new Point(20, 48);
            tbNoutInfo.Size       = new Size(440, 80);
            tbNoutInfo.Multiline  = true;
            tbNoutInfo.ReadOnly   = true;
            tbNoutInfo.BackColor  = Color.FromArgb(240, 240, 255);

            lblNoutCena = new Label();
            lblNoutCena.Location = new Point(20, 136);
            lblNoutCena.Size     = new Size(440, 22);
            lblNoutCena.ForeColor = Color.FromArgb(30, 130, 30);
            lblNoutCena.Font     = new Font("Segoe UI", 10f, FontStyle.Bold);

            btnNout = new Button();
            btnNout.Text      = "GetInfo() + RaschetStoimosti()";
            btnNout.Location  = new Point(20, 165);
            btnNout.Size      = new Size(280, 30);
            btnNout.BackColor = Color.FromArgb(67, 97, 238);
            btnNout.ForeColor = Color.White;
            btnNout.FlatStyle = FlatStyle.Flat;
            btnNout.FlatAppearance.BorderSize = 0;
            btnNout.Cursor    = Cursors.Hand;
            btnNout.Click    += BtnNout_Click;

            // ── Электроника ───────────────────────────────────────
            lblElek = new Label();
            lblElek.Text     = "Класс Elektronika (реализует IIzdelie):";
            lblElek.Location = new Point(20, 220);
            lblElek.Size     = new Size(440, 22);
            lblElek.Font     = new Font("Segoe UI", 10f, FontStyle.Bold);

            tbElekInfo = new TextBox();
            tbElekInfo.Location  = new Point(20, 248);
            tbElekInfo.Size      = new Size(440, 80);
            tbElekInfo.Multiline = true;
            tbElekInfo.ReadOnly  = true;
            tbElekInfo.BackColor = Color.FromArgb(240, 255, 240);

            lblElekCena = new Label();
            lblElekCena.Location  = new Point(20, 336);
            lblElekCena.Size      = new Size(440, 22);
            lblElekCena.ForeColor = Color.FromArgb(30, 130, 30);
            lblElekCena.Font      = new Font("Segoe UI", 10f, FontStyle.Bold);

            btnElek = new Button();
            btnElek.Text      = "GetInfo() + RaschetStoimosti()";
            btnElek.Location  = new Point(20, 365);
            btnElek.Size      = new Size(280, 30);
            btnElek.BackColor = Color.FromArgb(22, 163, 74);
            btnElek.ForeColor = Color.White;
            btnElek.FlatStyle = FlatStyle.Flat;
            btnElek.FlatAppearance.BorderSize = 0;
            btnElek.Cursor    = Cursors.Hand;
            btnElek.Click    += BtnElek_Click;

            // ── Добавляем всё на форму ─────────────────────────────
            this.Controls.Add(lblNout);
            this.Controls.Add(tbNoutInfo);
            this.Controls.Add(lblNoutCena);
            this.Controls.Add(btnNout);
            this.Controls.Add(lblElek);
            this.Controls.Add(tbElekInfo);
            this.Controls.Add(lblElekCena);
            this.Controls.Add(btnElek);
        }

        void BtnNout_Click(object sender, EventArgs e)
        {
            // Создаём объект через интерфейс — 2 ноутбука по 75000 руб.
            IIzdelie nout = new Notebook("Ноутбук ASUS VivoBook", 2, 75000, "ASUS");
            tbNoutInfo.Text   = nout.GetInfo();
            lblNoutCena.Text  = $"Общая стоимость (RaschetStoimosti): {nout.RaschetStoimosti()} руб.";
        }

        void BtnElek_Click(object sender, EventArgs e)
        {
            // Создаём объект через интерфейс — 1 единица за 15000 руб.
            IIzdelie elek = new Elektronika("Наушники Sony WH-1000XM5", 1, 15000, "Аудио");
            tbElekInfo.Text   = elek.GetInfo();
            lblElekCena.Text  = $"Общая стоимость (RaschetStoimosti): {elek.RaschetStoimosti()} руб.";
        }
    }
}
