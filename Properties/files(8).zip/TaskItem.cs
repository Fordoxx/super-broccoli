using System;

namespace TaskPlanner
{
    public class TaskItem
    {
        public Guid     Id          { get; set; } = Guid.NewGuid();
        public string   Title       { get; set; } = "";
        public string   Description { get; set; } = "";
        public DateTime Date        { get; set; } = DateTime.Today;
        public bool     AllDay      { get; set; } = true;
        public TimeSpan Time        { get; set; } = TimeSpan.Zero;
        public bool     IsDone      { get; set; } = false;

        // Для сохранения/загрузки из файла
        public string ToFileLine()
        {
            return $"{Id}|{Title}|{Description}|{Date:yyyy-MM-dd}|{AllDay}|{Time}|{IsDone}";
        }

        public static TaskItem FromFileLine(string line)
        {
            var p = line.Split('|');
            if (p.Length < 7) return null;
            return new TaskItem
            {
                Id          = Guid.Parse(p[0]),
                Title       = p[1],
                Description = p[2],
                Date        = DateTime.Parse(p[3]),
                AllDay      = bool.Parse(p[4]),
                Time        = TimeSpan.Parse(p[5]),
                IsDone      = bool.Parse(p[6]),
            };
        }

        public string TimeLabel =>
            AllDay ? "Весь день" : Time.ToString(@"hh\:mm");

        public string StatusLabel =>
            IsDone ? "✔ Выполнена" : "○ Не выполнена";
    }
}
