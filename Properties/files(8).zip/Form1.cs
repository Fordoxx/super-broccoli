using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace ArrayTasks
{
    public partial class Form1 : Form
    {
        // ── Палитра ───────────────────────────────────────────────────
        static readonly Color BG      = Color.FromArgb(245, 247, 252);
        static readonly Color ACCENT  = Color.FromArgb(37, 99, 235);
        static readonly Color GREEN   = Color.FromArgb(21, 128, 61);
        static readonly Color ORANGE  = Color.FromArgb(194, 120, 10);
        static readonly Color RED     = Color.FromArgb(185, 28, 28);
        static readonly Color BTN_BLU = Color.FromArgb(67, 97, 238);
        static readonly Color BTN_GRN = Color.FromArgb(22, 163, 74);
        static readonly Color SRC_BG  = Color.FromArgb(219, 234, 254);
        static readonly Color RES_BG  = Color.FromArgb(209, 250, 229);
        static readonly Color HDR_BG  = Color.FromArgb(30, 30, 70);

        // ── Контролы: Задание 1 ───────────────────────────────────────
        TextBox      txtT1Array, txtT1K;
        DataGridView dgvT1Src, dgvT1Res;
        Label        lblT1Msg;

        // ── Контролы: Задание 2 ───────────────────────────────────────
        TextBox      txtT2Array;
        DataGridView dgvT2Src, dgvT2Res;
        Label        lblT2Msg;

        // ── Контролы: Задание 3 ───────────────────────────────────────
        TextBox      txtT3Array;
        RadioButton  rbAsc, rbDesc;
        DataGridView dgvT3Src, dgvT3Res;

        // ── Контролы: Задание 4 ───────────────────────────────────────
        TextBox      txtT4M, txtT4N;
        DataGridView dgvT4Mat;
        Label        lblT4Res;
        int          t4M, t4N;

        // ── Контролы: Задание 5 ───────────────────────────────────────
        TextBox      txtT5M, txtT5N;
        DataGridView dgvT5Mat;
        Label        lblT5Res;
        int          t5M, t5N;

        // ═════════════════════════════════════════════════════════════
        public Form1()
        {
            InitializeComponent();
            foreach (TabPage tp in tabControl.TabPages) tp.BackColor = BG;
            BuildTab1();
            BuildTab2();
            BuildTab3();
            BuildTab4();
            BuildTab5();
        }

        // ═════════════════════════════════════════════════════════════
        //  ПОСТРОЕНИЕ ВКЛАДОК
        // ═════════════════════════════════════════════════════════════

        void BuildTab1()
        {
            var tab = tabPage1;

            MkTitle(tab, "Задание 1 — Замена серий массива", 10, 10);
            MkDesc(tab,
                "Дано целое K и массив размером N. Поменять местами 1-ю серию и серию с номером K. " +
                "Если серий меньше K — вывести массив без изменений. " +
                "Серия — группа подряд идущих одинаковых элементов.", 10, 44);

            // ── Строка ввода ──
            MkLbl(tab, "Массив (через запятую):", 10, 85);
            txtT1Array = MkTB(tab, 195, 82, 555, "3,3,1,2,2,2,5,7,7");
            MkLbl(tab, "K:", 762, 85);
            txtT1K = MkTB(tab, 778, 82, 55, "3");
            var btnRun = MkBtn(tab, "▶  Выполнить", 842, 80, 106, 28, BTN_BLU);
            btnRun.Click += (s, e) => RunTask1();

            // ── Исходный массив ──
            MkLbl(tab, "Исходный массив:", 10, 123, ACCENT, bold: true);
            dgvT1Src = MkDGV(tab, 10, 145, 938, 72, SRC_BG, readOnly: true);

            // ── Результат ──
            MkLbl(tab, "Результирующий массив:", 10, 228, GREEN, bold: true);
            dgvT1Res = MkDGV(tab, 10, 250, 938, 72, RES_BG, readOnly: true);

            lblT1Msg = MkLbl(tab, "", 10, 336, RED, width: 930);
            lblT1Msg.Font = new Font("Segoe UI", 9.5f, FontStyle.Italic);
        }

        void BuildTab2()
        {
            var tab = tabPage2;

            MkTitle(tab, "Задание 2 — Удаление элементов, встречающихся ровно 2 раза", 10, 10);
            MkDesc(tab,
                "Дан целочисленный массив размером N. Удалить из массива все элементы, " +
                "встречающиеся ровно два раза. Вывести размер полученного массива и его содержимое.", 10, 44);

            MkLbl(tab, "Массив (через запятую):", 10, 85);
            txtT2Array = MkTB(tab, 195, 82, 630, "1,2,3,2,4,3,5,5,6,7");
            var btnRun = MkBtn(tab, "▶  Выполнить", 840, 80, 110, 28, BTN_BLU);
            btnRun.Click += (s, e) => RunTask2();

            MkLbl(tab, "Исходный массив:", 10, 123, ACCENT, bold: true);
            dgvT2Src = MkDGV(tab, 10, 145, 938, 72, SRC_BG, readOnly: true);

            lblT2Msg = MkLbl(tab, "", 10, 228, GREEN, width: 930);
            lblT2Msg.Font = new Font("Segoe UI", 11f, FontStyle.Bold);

            MkLbl(tab, "Результирующий массив:", 10, 262, GREEN, bold: true);
            dgvT2Res = MkDGV(tab, 10, 284, 938, 72, RES_BG, readOnly: true);
        }

        void BuildTab3()
        {
            var tab = tabPage3;

            MkTitle(tab, "Задание 3 — Сортировка массива", 10, 10);
            MkDesc(tab,
                "Дан массив размером N. Осуществить сортировку элементов " +
                "по возрастанию или убыванию (тип сортировки указывает пользователь).", 10, 44);

            MkLbl(tab, "Массив (через запятую):", 10, 85);
            txtT3Array = MkTB(tab, 195, 82, 490, "42,15,7,33,8,100,3,77,55,21");

            rbAsc  = new RadioButton { Text = "↑  По возрастанию", Location = new Point(698, 84),
                Checked = true, AutoSize = true, Font = this.Font, BackColor = BG };
            rbDesc = new RadioButton { Text = "↓  По убыванию",    Location = new Point(840, 84),
                AutoSize = true, Font = this.Font, BackColor = BG };
            tab.Controls.Add(rbAsc);
            tab.Controls.Add(rbDesc);

            var btnRun = MkBtn(tab, "▶  Выполнить", 698, 112, 252, 28, BTN_BLU);
            btnRun.Click += (s, e) => RunTask3();

            MkLbl(tab, "Исходный массив:", 10, 153, ACCENT, bold: true);
            dgvT3Src = MkDGV(tab, 10, 175, 938, 72, SRC_BG, readOnly: true);

            MkLbl(tab, "Отсортированный массив:", 10, 260, GREEN, bold: true);
            dgvT3Res = MkDGV(tab, 10, 282, 938, 72, RES_BG, readOnly: true);
        }

        void BuildTab4()
        {
            var tab = tabPage4;

            MkTitle(tab, "Задание 4 — Столбец с максимальным числом одинаковых элементов", 10, 10);
            MkDesc(tab,
                "Дана целочисленная матрица размером M×N. Найти номер первого из её столбцов, " +
                "содержащих максимальное количество одинаковых элементов.", 10, 44);

            MkLbl(tab, "M (строк):", 10, 85);
            txtT4M = MkTB(tab, 88, 82, 55, "4");
            MkLbl(tab, "N (столбцов):", 158, 85);
            txtT4N = MkTB(tab, 258, 82, 55, "5");
            var btnSetup = MkBtn(tab, "📋  Создать матрицу", 328, 80, 160, 28, BTN_BLU);
            btnSetup.Click += (s, e) => SetupMatrix4();
            var btnRun = MkBtn(tab, "▶  Выполнить", 500, 80, 130, 28, BTN_GRN);
            btnRun.Click += (s, e) => RunTask4();

            MkLbl(tab, "Матрица (исходные данные — редактируемая):", 10, 123, ACCENT, bold: true);
            dgvT4Mat = MkDGV(tab, 10, 145, 938, 380, SRC_BG, readOnly: false);
            dgvT4Mat.AllowUserToAddRows = false;

            lblT4Res = MkLbl(tab, "", 10, 538, GREEN, width: 930);
            lblT4Res.Font = new Font("Segoe UI", 12f, FontStyle.Bold);

            // Матрица по умолчанию
            t4M = 4; t4N = 5;
            SetupMatrixDGV(dgvT4Mat, t4M, t4N);
            FillMatrix(dgvT4Mat, new int[,] {
                { 1, 2, 3, 1, 5 },
                { 1, 5, 6, 7, 5 },
                { 8, 2, 3, 1, 5 },
                { 1, 9, 3, 4, 5 }
            });
        }

        void BuildTab5()
        {
            var tab = tabPage5;

            MkTitle(tab, "Задание 5 — Строки без нулевых элементов", 10, 10);
            MkDesc(tab,
                "Дана целочисленная матрица размером M×N. " +
                "Определить количество строк, не содержащих ни одного нулевого элемента.", 10, 44);

            MkLbl(tab, "M (строк):", 10, 85);
            txtT5M = MkTB(tab, 88, 82, 55, "4");
            MkLbl(tab, "N (столбцов):", 158, 85);
            txtT5N = MkTB(tab, 258, 82, 55, "5");
            var btnSetup = MkBtn(tab, "📋  Создать матрицу", 328, 80, 160, 28, BTN_BLU);
            btnSetup.Click += (s, e) => SetupMatrix5();
            var btnRun = MkBtn(tab, "▶  Выполнить", 500, 80, 130, 28, BTN_GRN);
            btnRun.Click += (s, e) => RunTask5();

            MkLbl(tab, "Матрица (исходные данные — редактируемая):", 10, 123, ACCENT, bold: true);
            dgvT5Mat = MkDGV(tab, 10, 145, 938, 380, SRC_BG, readOnly: false);
            dgvT5Mat.AllowUserToAddRows = false;

            lblT5Res = MkLbl(tab, "", 10, 538, GREEN, width: 930);
            lblT5Res.Font = new Font("Segoe UI", 12f, FontStyle.Bold);

            // Матрица по умолчанию
            t5M = 4; t5N = 5;
            SetupMatrixDGV(dgvT5Mat, t5M, t5N);
            FillMatrix(dgvT5Mat, new int[,] {
                { 1, 2,  3, 4, 5 },
                { 0, 5,  6, 7, 8 },
                { 8, 9,  0, 1, 2 },
                { 2, 4,  6, 8, 3 }
            });
        }

        // ═════════════════════════════════════════════════════════════
        //  ОБРАБОТЧИКИ (ЛОГИКА ЗАДАНИЙ)
        // ═════════════════════════════════════════════════════════════

        // ── Задание 1 ─────────────────────────────────────────────────
        void RunTask1()
        {
            try
            {
                int[] arr = ParseArr(txtT1Array.Text);
                if (!int.TryParse(txtT1K.Text.Trim(), out int k) || k < 1)
                    throw new Exception("K должно быть натуральным числом.");

                ShowArr(dgvT1Src, arr);

                var series = GetSeries(arr);

                if (series.Count < k)
                {
                    ShowArr(dgvT1Res, arr);
                    SetMsg(lblT1Msg,
                        $"⚠  Серий в массиве: {series.Count} — меньше K = {k}. Массив выведен без изменений.",
                        ORANGE);
                }
                else
                {
                    int[] result = SwapSeries(arr, series, 0, k - 1);
                    ShowArr(dgvT1Res, result);
                    SetMsg(lblT1Msg,
                        $"✔  Серий в массиве: {series.Count}. " +
                        $"Серия №1 (значение {arr[series[0].start]}, длина {series[0].len}) " +
                        $"и серия №{k} (значение {arr[series[k-1].start]}, длина {series[k-1].len}) " +
                        "успешно поменяны местами.",
                        GREEN);
                }
            }
            catch (Exception ex) { SetMsg(lblT1Msg, "⚠  " + ex.Message, RED); }
        }

        // ── Задание 2 ─────────────────────────────────────────────────
        void RunTask2()
        {
            try
            {
                int[] arr = ParseArr(txtT2Array.Text);
                ShowArr(dgvT2Src, arr);

                var freq = arr.GroupBy(x => x).ToDictionary(g => g.Key, g => g.Count());
                int[] result = arr.Where(x => freq[x] != 2).ToArray();
                int removed = arr.Length - result.Length;

                SetMsg(lblT2Msg,
                    $"Размер нового массива: {result.Length}    " +
                    $"(исходный: {arr.Length},  удалено элементов: {removed})",
                    GREEN);
                ShowArr(dgvT2Res, result);
            }
            catch (Exception ex) { SetMsg(lblT2Msg, "⚠  " + ex.Message, RED); }
        }

        // ── Задание 3 ─────────────────────────────────────────────────
        void RunTask3()
        {
            try
            {
                int[] arr = ParseArr(txtT3Array.Text);
                ShowArr(dgvT3Src, arr);

                int[] sorted = (int[])arr.Clone();
                Array.Sort(sorted);
                if (rbDesc.Checked) Array.Reverse(sorted);
                ShowArr(dgvT3Res, sorted);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ── Задание 4: создать матрицу ─────────────────────────────────
        void SetupMatrix4()
        {
            try
            {
                t4M = int.Parse(txtT4M.Text.Trim());
                t4N = int.Parse(txtT4N.Text.Trim());
                if (t4M < 1 || t4N < 1 || t4M > 20 || t4N > 20)
                    throw new Exception("M и N должны быть от 1 до 20.");
                SetupMatrixDGV(dgvT4Mat, t4M, t4N);
                lblT4Res.Text = "";
            }
            catch (Exception ex) { SetMsg(lblT4Res, "⚠  " + ex.Message, RED); }
        }

        // ── Задание 4: выполнить ──────────────────────────────────────
        void RunTask4()
        {
            try
            {
                if (t4M == 0) throw new Exception("Сначала создайте матрицу.");
                int[,] mat = ReadMatrix(dgvT4Mat, t4M, t4N);
                int colIdx = FindColumnMaxSame(mat, t4M, t4N);
                int maxCnt = MaxSameInColumn(mat, t4M, colIdx);
                SetMsg(lblT4Res,
                    $"✔  Первый столбец с макс. числом одинаковых элементов: " +
                    $"№{colIdx + 1} (индекс {colIdx})  —  {maxCnt} одинаковых подряд не требуется, " +
                    $"просто {maxCnt} совпадающих значений.",
                    GREEN);
            }
            catch (Exception ex) { SetMsg(lblT4Res, "⚠  " + ex.Message, RED); }
        }

        // ── Задание 5: создать матрицу ─────────────────────────────────
        void SetupMatrix5()
        {
            try
            {
                t5M = int.Parse(txtT5M.Text.Trim());
                t5N = int.Parse(txtT5N.Text.Trim());
                if (t5M < 1 || t5N < 1 || t5M > 20 || t5N > 20)
                    throw new Exception("M и N должны быть от 1 до 20.");
                SetupMatrixDGV(dgvT5Mat, t5M, t5N);
                lblT5Res.Text = "";
            }
            catch (Exception ex) { SetMsg(lblT5Res, "⚠  " + ex.Message, RED); }
        }

        // ── Задание 5: выполнить ──────────────────────────────────────
        void RunTask5()
        {
            try
            {
                if (t5M == 0) throw new Exception("Сначала создайте матрицу.");
                int[,] mat = ReadMatrix(dgvT5Mat, t5M, t5N);
                int count = CountRowsNoZero(mat, t5M, t5N);
                SetMsg(lblT5Res,
                    $"✔  Строк без нулевых элементов: {count}  из  {t5M}.",
                    GREEN);
            }
            catch (Exception ex) { SetMsg(lblT5Res, "⚠  " + ex.Message, RED); }
        }

        // ═════════════════════════════════════════════════════════════
        //  АЛГОРИТМЫ
        // ═════════════════════════════════════════════════════════════

        // Задание 1 — нахождение серий
        List<(int start, int len)> GetSeries(int[] arr)
        {
            var list = new List<(int, int)>();
            int i = 0;
            while (i < arr.Length)
            {
                int j = i + 1;
                while (j < arr.Length && arr[j] == arr[i]) j++;
                list.Add((i, j - i));
                i = j;
            }
            return list;
        }

        // Задание 1 — замена серий с индексами si и sj
        int[] SwapSeries(int[] arr, List<(int start, int len)> series, int si, int sj)
        {
            if (si == sj) return (int[])arr.Clone();
            if (si > sj) { int t = si; si = sj; sj = t; }

            int s1 = series[si].start, l1 = series[si].len;
            int s2 = series[sj].start, l2 = series[sj].len;
            int v1 = arr[s1], v2 = arr[s2];

            // Строим новый массив: меняем значения серий, длины сохраняем
            // (замена серий — обмен значениями, длины остаются на своих местах)
            var result = new List<int>();
            for (int i = 0; i < arr.Length;)
            {
                if (i == s1)
                {
                    for (int k = 0; k < l1; k++) result.Add(v2);
                    i += l1;
                }
                else if (i == s2)
                {
                    for (int k = 0; k < l2; k++) result.Add(v1);
                    i += l2;
                }
                else
                {
                    result.Add(arr[i++]);
                }
            }
            return result.ToArray();
        }

        // Задание 4 — найти столбец с максимальным числом одинаковых элементов
        int FindColumnMaxSame(int[,] mat, int M, int N)
        {
            int bestCol = 0, bestMax = 0;
            for (int c = 0; c < N; c++)
            {
                int mx = MaxSameInColumn(mat, M, c);
                if (mx > bestMax) { bestMax = mx; bestCol = c; }
            }
            return bestCol;
        }

        int MaxSameInColumn(int[,] mat, int M, int col)
        {
            var freq = new Dictionary<int, int>();
            for (int r = 0; r < M; r++)
            {
                int v = mat[r, col];
                freq[v] = freq.ContainsKey(v) ? freq[v] + 1 : 1;
            }
            return freq.Values.Max();
        }

        // Задание 5 — строки без нулей
        int CountRowsNoZero(int[,] mat, int M, int N)
        {
            int cnt = 0;
            for (int r = 0; r < M; r++)
            {
                bool hasZero = false;
                for (int c = 0; c < N; c++)
                    if (mat[r, c] == 0) { hasZero = true; break; }
                if (!hasZero) cnt++;
            }
            return cnt;
        }

        // ═════════════════════════════════════════════════════════════
        //  ВСПОМОГАТЕЛЬНЫЕ МЕТОДЫ ДАННЫХ
        // ═════════════════════════════════════════════════════════════

        int[] ParseArr(string text)
        {
            string[] parts = text.Split(new[] { ',', ';', ' ' }, StringSplitOptions.RemoveEmptyEntries);
            if (parts.Length == 0) throw new Exception("Массив не может быть пустым.");
            int[] arr = new int[parts.Length];
            for (int i = 0; i < parts.Length; i++)
                if (!int.TryParse(parts[i].Trim(), out arr[i]))
                    throw new Exception($"Неверное значение: «{parts[i].Trim()}»");
            return arr;
        }

        int[,] ReadMatrix(DataGridView dgv, int M, int N)
        {
            var mat = new int[M, N];
            for (int r = 0; r < M; r++)
                for (int c = 0; c < N; c++)
                {
                    string s = dgv.Rows[r].Cells[c].Value?.ToString() ?? "";
                    if (!int.TryParse(s, out mat[r, c]))
                        throw new Exception($"Неверное значение в ячейке [{r + 1},{c + 1}]: «{s}»");
                }
            return mat;
        }

        // Показать 1D массив в DataGridView (строка = заголовок-индекс, столбец = значение)
        void ShowArr(DataGridView dgv, int[] arr)
        {
            dgv.Columns.Clear();
            dgv.Rows.Clear();
            dgv.RowHeadersVisible = false;

            if (arr.Length == 0)
            {
                dgv.Columns.Add("empty", "—  пустой массив  —");
                dgv.Rows.Add("нет элементов");
                return;
            }

            for (int i = 0; i < arr.Length; i++)
            {
                var col = dgv.Columns.Add($"c{i}", $"[{i}]");
                dgv.Columns[col].MinimumWidth = 48;
            }

            dgv.Rows.Add(arr.Select(x => (object)x).ToArray());
            dgv.AutoResizeColumns(DataGridViewAutoSizeColumnsMode.AllCells);
        }

        // Создать пустую редактируемую матрицу в DataGridView
        void SetupMatrixDGV(DataGridView dgv, int M, int N)
        {
            dgv.Columns.Clear();
            dgv.Rows.Clear();
            dgv.RowHeadersVisible = true;
            dgv.RowHeadersWidth   = 48;

            for (int c = 0; c < N; c++)
            {
                int idx = dgv.Columns.Add($"c{c}", $"[{c}]");
                dgv.Columns[idx].MinimumWidth = 64;
                dgv.Columns[idx].Width        = 70;
            }

            for (int r = 0; r < M; r++)
            {
                int rowIdx = dgv.Rows.Add();
                dgv.Rows[rowIdx].HeaderCell.Value = $"[{r}]";
                for (int c = 0; c < N; c++)
                    dgv.Rows[rowIdx].Cells[c].Value = 0;
            }
        }

        // Заполнить DGV готовыми данными
        void FillMatrix(DataGridView dgv, int[,] data)
        {
            int rows = Math.Min(dgv.Rows.Count, data.GetLength(0));
            int cols = Math.Min(dgv.Columns.Count, data.GetLength(1));
            for (int r = 0; r < rows; r++)
                for (int c = 0; c < cols; c++)
                    dgv.Rows[r].Cells[c].Value = data[r, c];
        }

        // ═════════════════════════════════════════════════════════════
        //  ФАБРИКА UI-КОНТРОЛОВ
        // ═════════════════════════════════════════════════════════════

        Label MkTitle(Control p, string text, int x, int y)
        {
            var lbl = new Label
            {
                Text      = text,
                Location  = new Point(x, y),
                Font      = new Font("Segoe UI", 12f, FontStyle.Bold),
                ForeColor = HDR_BG,
                AutoSize  = true,
                BackColor = Color.Transparent,
            };
            p.Controls.Add(lbl);
            return lbl;
        }

        Label MkDesc(Control p, string text, int x, int y)
        {
            var lbl = new Label
            {
                Text      = text,
                Location  = new Point(x, y),
                Font      = new Font("Segoe UI", 9f),
                ForeColor = Color.FromArgb(80, 80, 100),
                AutoSize  = false,
                Width     = 938,
                Height    = 34,
                BackColor = Color.Transparent,
            };
            p.Controls.Add(lbl);
            return lbl;
        }

        Label MkLbl(Control p, string text, int x, int y,
            Color? color = null, bool bold = false, int width = 0)
        {
            var lbl = new Label
            {
                Text      = text,
                Location  = new Point(x, y),
                Font      = bold
                              ? new Font("Segoe UI", 9.5f, FontStyle.Bold)
                              : this.Font,
                ForeColor = color ?? Color.FromArgb(30, 30, 30),
                AutoSize  = width == 0,
                BackColor = Color.Transparent,
            };
            if (width > 0) { lbl.Width = width; lbl.AutoSize = false; }
            p.Controls.Add(lbl);
            return lbl;
        }

        TextBox MkTB(Control p, int x, int y, int w, string def = "")
        {
            var tb = new TextBox
            {
                Location = new Point(x, y),
                Width    = w,
                Text     = def,
                Font     = this.Font,
            };
            p.Controls.Add(tb);
            return tb;
        }

        Button MkBtn(Control p, string text, int x, int y, int w, int h, Color bg)
        {
            var btn = new Button
            {
                Text      = text,
                Location  = new Point(x, y),
                Size      = new Size(w, h),
                BackColor = bg,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font      = new Font("Segoe UI", 9.5f, FontStyle.Bold),
                Cursor    = Cursors.Hand,
            };
            btn.FlatAppearance.BorderSize = 0;
            p.Controls.Add(btn);
            return btn;
        }

        DataGridView MkDGV(Control p, int x, int y, int w, int h, Color bg, bool readOnly)
        {
            var dgv = new DataGridView
            {
                Location                         = new Point(x, y),
                Size                             = new Size(w, h),
                AllowUserToAddRows               = false,
                AllowUserToDeleteRows            = false,
                ReadOnly                         = readOnly,
                BackgroundColor                  = bg,
                GridColor                        = Color.FromArgb(180, 205, 240),
                BorderStyle                      = BorderStyle.FixedSingle,
                RowHeadersVisible                = false,
                ColumnHeadersHeightSizeMode      = DataGridViewColumnHeadersHeightSizeMode.DisableResizing,
                ColumnHeadersHeight              = 26,
                ScrollBars                       = ScrollBars.Both,
                SelectionMode                    = DataGridViewSelectionMode.CellSelect,
                MultiSelect                      = false,
                AutoSizeColumnsMode              = DataGridViewAutoSizeColumnsMode.None,
                EnableHeadersVisualStyles        = false,
            };

            // Заголовки
            dgv.ColumnHeadersDefaultCellStyle.BackColor  = Color.FromArgb(200, 220, 255);
            dgv.ColumnHeadersDefaultCellStyle.Font       = new Font("Segoe UI", 9f, FontStyle.Bold);
            dgv.ColumnHeadersDefaultCellStyle.Alignment  = DataGridViewContentAlignment.MiddleCenter;
            dgv.ColumnHeadersDefaultCellStyle.ForeColor  = Color.FromArgb(30, 30, 90);

            // Ячейки
            dgv.DefaultCellStyle.Font                    = new Font("Segoe UI", 10.5f, FontStyle.Bold);
            dgv.DefaultCellStyle.Alignment               = DataGridViewContentAlignment.MiddleCenter;
            dgv.DefaultCellStyle.BackColor               = bg;
            dgv.DefaultCellStyle.ForeColor               = Color.FromArgb(20, 20, 60);

            // Заголовки строк (для матриц)
            dgv.RowHeadersDefaultCellStyle.BackColor     = Color.FromArgb(200, 220, 255);
            dgv.RowHeadersDefaultCellStyle.Font          = new Font("Segoe UI", 9f, FontStyle.Bold);
            dgv.RowHeadersDefaultCellStyle.Alignment     = DataGridViewContentAlignment.MiddleCenter;
            dgv.RowHeadersDefaultCellStyle.ForeColor     = Color.FromArgb(30, 30, 90);

            dgv.RowTemplate.Height = 30;

            // Двойная буферизация (против мерцания)
            typeof(DataGridView)
                .GetProperty("DoubleBuffered",
                    System.Reflection.BindingFlags.Instance |
                    System.Reflection.BindingFlags.NonPublic)
                ?.SetValue(dgv, true, null);

            p.Controls.Add(dgv);
            return dgv;
        }

        void SetMsg(Label lbl, string text, Color color)
        {
            lbl.ForeColor = color;
            lbl.Text      = text;
        }
    }
}
