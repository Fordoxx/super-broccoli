using System;
using System.Drawing;
using System.Windows.Forms;

namespace TaskPlanner
{
    public class AddTaskForm : Form
    {
        public TaskItem Result { get; private set; }

        TextBox       tbTitle, tbDesc;
        DateTimePicker dtpDate;
        CheckBox      chkAllDay;
        DateTimePicker dtpTime;
        Label         lblTime;

        public AddTaskForm(TaskItem existing = null)
        {
            this.Text            = existing == null ? "Новая задача" : "Редактировать задачу";
            this.Size            = new Size(400, 340);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition   = FormStartPosition.CenterParent;
            this.MaximizeBox     = false;
            this.MinimizeBox     = false;
            this.Font            = new Font("Segoe UI", 10f);
            this.BackColor       = Color.FromArgb(245, 247, 252);

            // ── Название ──────────────────────────────────────────
            Lbl("Название задачи:", 14, 14);
            tbTitle = new TextBox { Location = new Point(14, 36), Width = 355 };
            this.Controls.Add(tbTitle);

            // ── Описание ──────────────────────────────────────────
            Lbl("Описание (необязательно):", 14, 72);
            tbDesc = new TextBox
            {
                Location  = new Point(14, 94),
                Size      = new Size(355, 56),
                Multiline = true,
            };
            this.Controls.Add(tbDesc);

            // ── Дата ──────────────────────────────────────────────
            Lbl("Дата:", 14, 164);
            dtpDate = new DateTimePicker
            {
                Location = new Point(14, 186),
                Width    = 180,
                Format   = DateTimePickerFormat.Short,
                Value    = DateTime.Today,
            };
            this.Controls.Add(dtpDate);

            // ── Весь день ─────────────────────────────────────────
            chkAllDay = new CheckBox
            {
                Text     = "Весь день",
                Location = new Point(210, 188),
                AutoSize = true,
                Checked  = true,
            };
            chkAllDay.CheckedChanged += (s, e) =>
            {
                dtpTime.Visible = !chkAllDay.Checked;
                lblTime.Visible = !chkAllDay.Checked;
            };
            this.Controls.Add(chkAllDay);

            // ── Время ─────────────────────────────────────────────
            lblTime = Lbl("Время:", 14, 222);
            lblTime.Visible = false;
            dtpTime = new DateTimePicker
            {
                Location = new Point(14, 244),
                Width    = 120,
                Format   = DateTimePickerFormat.Time,
                ShowUpDown = true,
                Value    = DateTime.Today.AddHours(9),
            };
            dtpTime.Visible = false;
            this.Controls.Add(dtpTime);

            // ── Кнопки ────────────────────────────────────────────
            var btnOk = new Button
            {
                Text      = "Сохранить",
                Location  = new Point(200, 264),
                Size      = new Size(90, 30),
                BackColor = Color.FromArgb(67, 97, 238),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font      = new Font("Segoe UI", 10f, FontStyle.Bold),
                Cursor    = Cursors.Hand,
            };
            btnOk.FlatAppearance.BorderSize = 0;
            btnOk.Click += BtnOk_Click;

            var btnCancel = new Button
            {
                Text      = "Отмена",
                Location  = new Point(300, 264),
                Size      = new Size(70, 30),
                BackColor = Color.FromArgb(180, 180, 180),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Cursor    = Cursors.Hand,
            };
            btnCancel.FlatAppearance.BorderSize = 0;
            btnCancel.Click += (s, e) => this.DialogResult = DialogResult.Cancel;

            this.Controls.Add(btnOk);
            this.Controls.Add(btnCancel);

            // ── Заполнить если редактирование ─────────────────────
            if (existing != null)
            {
                tbTitle.Text      = existing.Title;
                tbDesc.Text       = existing.Description;
                dtpDate.Value     = existing.Date;
                chkAllDay.Checked = existing.AllDay;
                if (!existing.AllDay)
                    dtpTime.Value = DateTime.Today.Add(existing.Time);
            }
        }

        void BtnOk_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tbTitle.Text))
            {
                MessageBox.Show("Введите название задачи.", "Ошибка",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            Result = new TaskItem
            {
                Title       = tbTitle.Text.Trim(),
                Description = tbDesc.Text.Trim(),
                Date        = dtpDate.Value.Date,
                AllDay      = chkAllDay.Checked,
                Time        = chkAllDay.Checked
                                ? TimeSpan.Zero
                                : dtpTime.Value.TimeOfDay,
            };
            this.DialogResult = DialogResult.OK;
        }

        Label Lbl(string text, int x, int y)
        {
            var l = new Label { Text = text, Location = new Point(x, y),
                AutoSize = true, BackColor = Color.Transparent };
            this.Controls.Add(l);
            return l;
        }
    }
}
