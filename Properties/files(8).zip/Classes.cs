// Класс 1 - Ноутбук
public class Notebook : IIzdelie
{
    public string Imya;
    public int    Kolichestvo;
    public double Cena;
    public string Brend;

    public Notebook(string imya, int kolichestvo, double cena, string brend)
    {
        Imya        = imya;
        Kolichestvo = kolichestvo;
        Cena        = cena;
        Brend       = brend;
    }

    public string GetInfo()
    {
        return $"Ноутбук: {Imya}\nБренд: {Brend}\nКоличество: {Kolichestvo} шт.\nЦена: {Cena} руб.";
    }

    public double RaschetStoimosti()
    {
        return Kolichestvo * Cena;
    }
}

// Класс 2 - Электроника
public class Elektronika : IIzdelie
{
    public string Imya;
    public int    Kolichestvo;
    public double Cena;
    public string Kategoriya;

    public Elektronika(string imya, int kolichestvo, double cena, string kategoriya)
    {
        Imya        = imya;
        Kolichestvo = kolichestvo;
        Cena        = cena;
        Kategoriya  = kategoriya;
    }

    public string GetInfo()
    {
        return $"Электроника: {Imya}\nКатегория: {Kategoriya}\nКоличество: {Kolichestvo} шт.\nЦена: {Cena} руб.";
    }

    public double RaschetStoimosti()
    {
        return Kolichestvo * Cena;
    }
}
