// =====================================================
//  Базовый класс: Изделие
// =====================================================
public class Izdelie
{
    // --- Поля по заданию ---
    public string Imya       { get; set; }   // имя
    public string Kategoriya { get; set; }   // категория
    public int    Kolichestvo{ get; set; }   // количество

    // --- Два доп. поля по своему усмотрению ---
    public double Cena       { get; set; }   // цена за единицу
    public string Postavshik { get; set; }   // поставщик

    // --- Конструктор по умолчанию ---
    public Izdelie()
    {
        Imya        = "Без названия";
        Kategoriya  = "Без категории";
        Kolichestvo = 0;
        Cena        = 0.0;
        Postavshik  = "Не указан";
    }

    // --- Конструктор с аргументами ---
    public Izdelie(string imya, string kategoriya, int kolichestvo,
                   double cena, string postavshik)
    {
        Imya        = imya;
        Kategoriya  = kategoriya;
        Kolichestvo = kolichestvo;
        Cena        = cena;
        Postavshik  = postavshik;
    }

    // --- Функция вывода полей ---
    public string Vivesti()
    {
        return $"Изделие: {Imya}\n" +
               $"Категория: {Kategoriya}\n" +
               $"Количество: {Kolichestvo} шт.\n" +
               $"Цена: {Cena:F2} руб.\n" +
               $"Поставщик: {Postavshik}";
    }

    // --- Виртуальный метод ---
    public virtual string GetInfo()
    {
        return $"[Изделие] {Imya} | {Kategoriya} | {Kolichestvo} шт.";
    }
}

// =====================================================
//  Дочерний класс 1: Электроника
// =====================================================
public class Elektronika : Izdelie
{
    // --- Два доп. поля дочернего класса ---
    public string Brend    { get; set; }   // бренд
    public double Garantiya{ get; set; }   // гарантия (лет)

    // --- Конструктор по умолчанию ---
    public Elektronika() : base()
    {
        Brend     = "Неизвестно";
        Garantiya = 0;
    }

    // --- Конструктор с аргументами ---
    public Elektronika(string imya, string kategoriya, int kolichestvo,
                       double cena, string postavshik,
                       string brend, double garantiya)
        : base(imya, kategoriya, kolichestvo, cena, postavshik)
    {
        Brend     = brend;
        Garantiya = garantiya;
    }

    // --- Перегрузка виртуального метода ---
    public override string GetInfo()
    {
        return $"[Электроника] {Imya} | Бренд: {Brend} | " +
               $"Гарантия: {Garantiya} лет | {Kolichestvo} шт.";
    }
}

// =====================================================
//  Дочерний класс 2: Стройматериал
// =====================================================
public class Strojmaterial : Izdelie
{
    // --- Два доп. поля дочернего класса ---
    public double Ves      { get; set; }   // вес единицы (кг)
    public string Material { get; set; }   // материал (дерево, металл и т.д.)

    // --- Конструктор по умолчанию ---
    public Strojmaterial() : base()
    {
        Ves      = 0.0;
        Material = "Не указан";
    }

    // --- Конструктор с аргументами ---
    public Strojmaterial(string imya, string kategoriya, int kolichestvo,
                         double cena, string postavshik,
                         double ves, string material)
        : base(imya, kategoriya, kolichestvo, cena, postavshik)
    {
        Ves      = ves;
        Material = material;
    }

    // --- Перегрузка виртуального метода ---
    public override string GetInfo()
    {
        return $"[Стройматериал] {Imya} | Материал: {Material} | " +
               $"Вес: {Ves} кг | {Kolichestvo} шт.";
    }
}
