// Интерфейс для изделия
// Метод 1 - вывод информации
// Метод 2 - расчёт общей стоимости
public interface IIzdelie
{
    string GetInfo();
    double RaschetStoimosti();
}
